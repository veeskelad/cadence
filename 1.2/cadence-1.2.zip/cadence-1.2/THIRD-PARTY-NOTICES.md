# Сторонние компоненты

Cadence распространяется по лицензии MIT (`LICENSE.txt`). Чужие компоненты внутри набора
сохраняют свои лицензии. Их тексты лежат рядом с самими компонентами.

| Компонент | Где | Лицензия | Текст лицензии |
|---|---|---|---|
| three.js | `engine/vendor/three/` | MIT, © three.js authors | `engine/vendor/three/LICENSE` |
| Literata | `engine/fonts/literata/` | SIL Open Font License 1.1 | `engine/fonts/literata/LICENSE` |
| Manrope | `engine/fonts/manrope/` | SIL Open Font License 1.1 | `engine/fonts/manrope/LICENSE` |
| JetBrains Mono | `engine/fonts/jetbrains-mono/` | SIL Open Font License 1.1 | `engine/fonts/jetbrains-mono/LICENSE` |
| Onest | `engine/fonts/onest/` | SIL Open Font License 1.1 | `engine/fonts/onest/LICENSE` |

## Не входят в архив, ставятся отдельно

| Компонент | Как попадает | Лицензия |
|---|---|---|
| HyperFrames | `npm --prefix engine install` | Apache 2.0 |
| Chrome без окна (рендер) | скачивает HyperFrames при установке | лицензия Chromium и Google |
| Whisper (субтитры, по желанию) | ставишь сам: `pip install openai-whisper` или `faster-whisper` | MIT |
| Навыки HyperFrames и Remotion (по желанию) | `npx skills add …` из первоисточника | у каждого своя; Remotion бесплатен для одиночек и команд до 3 человек |

## Источники знаний

Словарь приёмов `knowledge/techniques/` — пересказ своими словами открытого каталога
кинематографических приёмов melies.co/cinematic-techniques; дословных карточек каталога в наборе нет.
Рецепты банка эффектов ссылаются на публичные ролики, по которым разобран приём; сами ролики
в набор не входят.

## Звуки и музыка

Звуки в `sounds/` и демо-бит синтезированы кодом этого набора (`scripts/make_sounds.py`,
`scripts/demo_beat.py`) и распространяются по MIT вместе с ним. Чужой музыки в наборе нет.
Права на трек, который ты подкладываешь сам, — на тебе. Для публикации бери свой трек или
трек из библиотеки площадки.
